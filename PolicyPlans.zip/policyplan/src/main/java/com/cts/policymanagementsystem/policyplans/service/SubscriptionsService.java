package com.cts.policymanagementsystem.policyplans.service;

import com.cts.policymanagementsystem.policyplans.entities.Subscriptions;


public interface SubscriptionsService {
	
	
	//e. Add new subscription
	Subscriptions addSubscriptions( Subscriptions subscriptions);

}
