package com.cts.policymanagementsystem.policyplans.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
//@Setter
//@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Policytypes")
public class PolicyTypes {
	 
	@Id
	@Column(name = "id", length=10)
	private int id;
	@Column(name = "type", length= 10)
	private String type;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	@Override
	public String toString() {
		return "PolicyTypes [id=" + id + ", type=" + type + "]";
	}
	
	


}
