package com.cts.policymanagementsystem.policyplans.repos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.cts.policymanagementsystem.policyplans.entities.Policies;

public interface PoliciesRepository extends CrudRepository<Policies, Integer> {
	
	Policies save(Policies policies);
	 
	 List<Policies> findByTenureOrMonthlyPremiumOrMaturityAmount(int tenure, int premiumAmount, float maturityAmount);

	 Policies findById(int id);
	 //Optional<Policies> findById(Long id);
}
