package com.cts.policymanagementsystem.policyplans.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.policymanagementsystem.policyplans.entities.Policies;
import com.cts.policymanagementsystem.policyplans.service.PoliciesService;

@RestController
@RequestMapping("/api/policy")
public class PoliciesController {

	@Autowired
	private PoliciesService policiesService;

	@PostMapping()
	public ResponseEntity<Policies> createPolicy(@RequestBody Policies policy) {
	Policies createdPolicy = policiesService.createPolicy(policy);
	return ResponseEntity.status(HttpStatus.CREATED).body(createdPolicy);
	}
	
	
	@GetMapping("/{tenure}/{premiumAmount}/{montlyAmount}")
	public List<Policies> searchPoliciesByCriteria(@PathVariable int  tenure,@PathVariable int premiumAmount,@PathVariable float maturityAmoun){
	return policiesService.searchPoliciesByCriteria(tenure, premiumAmount, maturityAmoun);
	
	}
	
	@GetMapping("/{policyid}")
	public Policies getPolicyById(@PathVariable int policyid) {
		return policiesService.getPolicyById(policyid);
	}
	
	@GetMapping()
	public String gello() {
		return "A";
	}
	
}

        
       


