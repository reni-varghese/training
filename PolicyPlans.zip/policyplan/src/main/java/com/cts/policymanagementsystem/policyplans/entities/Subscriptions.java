package com.cts.policymanagementsystem.policyplans.entities;

import java.time.LocalDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
//import lombok.Getter;
import lombok.NoArgsConstructor;
//import lombok.Setter;


@Data
//@Setter
//@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
//@Table(name = "Subscriptions")
public class Subscriptions {
	
	@Id
	@Column(name = "subscriptionid", length=10)
	private int subscriptionId;
	
	@Column(name = "policyid", length=10)
	private int policyId;
	
	@Column(name = "subscriptiondate", length= 10)
//    @Column(columnDefinition = "DATE DEFAULT CURRENT_DATE")
	private LocalDate subscriptionDate;

	
	@Pattern(regexp = "^.{5,}$", message = "Policy holder name must have a minimum of 5 characters")
	@Column(name = "policyholdername", length=50)
	private String policyHolderName;
	
	@Column(name = "username", length= 6)
	private String username;
	
	@Pattern(regexp = "^(New|Matured|Defaulted|Terminated)$")
	@Column(name = "subscriptionstatus", length= 15)
	private String subscriptionStatus;
	@Column(name = "medicalcertificatedocurl", length=200)
	private String medicalCertificateDocUrl;
	
	@Pattern(regexp = "^(Parent|Child|Sibling|Spouse|Cousin)$")
	@Column(name = "relationtopolicyholder", length= 15)
	private String relationToPolicyHolder;
	
	@Column(name = "policyholderidprooftype", length= 10)
	private String policyHolderIdProofType;
	@Column(name = "policyholderidproofno", length= 12)
	private String policyHolderIdProofNo;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "policiespolicyid", referencedColumnName = "policyid")
	private Policies policies;

	
	
	public int getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(int subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public int getPolicyId() {
		return policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public LocalDate getSubscriptionDate() {
		return subscriptionDate;
	}

	public void setSubscriptionDate(LocalDate subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}

	public String getPolicyHolderName() {
		return policyHolderName;
	}

	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getSubscriptionStatus() {
		return subscriptionStatus;
	}

	public void setSubscriptionStatus(String subscriptionStatus) {
		this.subscriptionStatus = subscriptionStatus;
	}

	public String getMedicalCertificateDocUrl() {
		return medicalCertificateDocUrl;
	}

	public void setMedicalCertificateDocUrl(String medicalCertificateDocUrl) {
		this.medicalCertificateDocUrl = medicalCertificateDocUrl;
	}

	public String getRelationToPolicyHolder() {
		return relationToPolicyHolder;
	}

	public void setRelationToPolicyHolder(String relationToPolicyHolder) {
		this.relationToPolicyHolder = relationToPolicyHolder;
	}

	public String getPolicyHolderIdProofType() {
		return policyHolderIdProofType;
	}

	public void setPolicyHolderIdProofType(String policyHolderIdProofType) {
		this.policyHolderIdProofType = policyHolderIdProofType;
	}

	public String getPolicyHolderIdProofNo() {
		return policyHolderIdProofNo;
	}

	public void setPolicyHolderIdProofNo(String policyHolderIdProofNo) {
		this.policyHolderIdProofNo = policyHolderIdProofNo;
	}

	public Policies getPolicies() {
		return policies;
	}

	public void setPolicies(Policies policies) {
		this.policies = policies;
	}

	@Override
	public String toString() {
		return "Subscriptions [subscriptionId=" + subscriptionId + ", policyId=" + policyId + ", subscriptionDate="
				+ subscriptionDate + ", policyHolderName=" + policyHolderName + ", username=" + username
				+ ", subscriptionStatus=" + subscriptionStatus + ", medicalCertificateDocUrl="
				+ medicalCertificateDocUrl + ", relationToPolicyHolder=" + relationToPolicyHolder
				+ ", policyHolderIdProofType=" + policyHolderIdProofType + ", policyHolderIdProofNo="
				+ policyHolderIdProofNo + ", policies=" + policies + "]";
	}
	
	
	
	
	

}
