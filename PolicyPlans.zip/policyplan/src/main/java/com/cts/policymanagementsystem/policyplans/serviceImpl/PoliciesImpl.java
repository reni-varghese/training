package com.cts.policymanagementsystem.policyplans.serviceImpl;

import java.util.List;
//import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.policymanagementsystem.policyplans.entities.Policies;
import com.cts.policymanagementsystem.policyplans.exceptions.PolicyNotFoundException;
import com.cts.policymanagementsystem.policyplans.repos.PoliciesRepository;
import com.cts.policymanagementsystem.policyplans.service.PoliciesService;


@Service
public class PoliciesImpl implements PoliciesService {
	
	@Autowired
	private PoliciesRepository repository;

	
	//b. Insert a new policy
	@Override
	public Policies createPolicy(Policies policies) {

		
		return repository.save(policies);
	}

	
	//c. Return list of policies by tenure or premium amount or maturity amount
	@Override
	public List<Policies> searchPoliciesByCriteria(int tenure, int premiumAmount, float maturityAmount) {

	List<Policies> newPoliciesList=repository.findByTenureOrMonthlyPremiumOrMaturityAmount(tenure, premiumAmount, maturityAmount);
	return newPoliciesList;
	}

	
	//d. Return a policy by id
	@Override
	public Policies getPolicyById(int id) {
		Policies policy = repository.findById(id);
        if (policy == null) {
            throw new PolicyNotFoundException("Policy not found with ID: " + id);
        }
        return policy;
	}
	
	

}
