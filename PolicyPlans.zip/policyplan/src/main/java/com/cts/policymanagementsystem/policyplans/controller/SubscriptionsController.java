package com.cts.policymanagementsystem.policyplans.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.policymanagementsystem.policyplans.entities.Subscriptions;
import com.cts.policymanagementsystem.policyplans.service.SubscriptionsService;

import jakarta.validation.Valid;

@RestController
public class SubscriptionsController {
	
	@Autowired
	private SubscriptionsService subscriptionsService;
	
	@PostMapping("/api/policy/{policyid}/subscribe")
	public ResponseEntity<Subscriptions> createSubscription(@PathVariable int policyId, @Valid @RequestBody Subscriptions subscriptions){
		subscriptions.setPolicyId(policyId);
		Subscriptions savedSubscription = subscriptionsService.addSubscriptions(subscriptions);
        
        return ResponseEntity.ok(savedSubscription);
	}
            
	
	

}
