package com.cts.policymanagementsystem.policyplans.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.policymanagementsystem.policyplans.entities.PolicyTypes;
import com.cts.policymanagementsystem.policyplans.service.PolicyTypesService;

@RestController
public class PolicyTypesController {
	
	@Autowired
	private PolicyTypesService policyTypesService;
	
	
//	public PolicyTypes getPolicyTypes() {
//		
//		PolicyTypes types = new PolicyTypes();
//		types.setType("Life Insurance");
//		return types;
//		
//	}
	@GetMapping("/api/policy/types")
	public List<PolicyTypes> getAllPolicyTypes(){
		return policyTypesService.getAllPolicyTypes();
	}
	
	

}
