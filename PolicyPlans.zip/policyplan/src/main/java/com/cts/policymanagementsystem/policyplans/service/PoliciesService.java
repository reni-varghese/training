package com.cts.policymanagementsystem.policyplans.service;

import java.util.List;

import com.cts.policymanagementsystem.policyplans.entities.Policies;

public interface PoliciesService {
	
	//b. Insert a new policy
	Policies createPolicy(Policies policies);
	
	
	//c. Return list of policies by tenure or premium amount or maturity amount
	List<Policies> searchPoliciesByCriteria(int tenure, int premiumAmount, float maturityAmount);
	
	
	//d. Return a policy by id
	Policies getPolicyById(int id);
	
	//Optional<Policies> getPolicyById(int id);
	


}
