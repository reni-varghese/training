package com.cts.policymanagementsystem.policyplans.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.policymanagementsystem.policyplans.entities.PolicyTypes;
import com.cts.policymanagementsystem.policyplans.repos.PolicyTypesRepository;
import com.cts.policymanagementsystem.policyplans.service.PolicyTypesService;

@Service
public class PolicyTypesImpl implements PolicyTypesService {

	
	@Autowired
	private PolicyTypesRepository repository;

	
	//a. Get all policy types list
	@Override
	
	public List<PolicyTypes> getAllPolicyTypes() {

		return repository.findAll();
	}
	
	
	

}
