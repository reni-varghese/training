package com.cts.policymanagementsystem.policyplans.repos;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cts.policymanagementsystem.policyplans.entities.PolicyTypes;

public interface PolicyTypesRepository extends CrudRepository<PolicyTypes, String> {
	
	
	//a. Get all policy types list
	List<PolicyTypes> findAll();

}
