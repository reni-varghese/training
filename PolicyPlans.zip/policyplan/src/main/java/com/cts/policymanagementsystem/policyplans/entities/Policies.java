package com.cts.policymanagementsystem.policyplans.entities;

import jakarta.persistence.CascadeType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity 
@Table(name = "Policies")
public class Policies {
	
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)  
	@Column(name = "policyid", length= 10)
	private int policyId;
	@Column(name = "policyname", length= 30)
	private String policyName;
	@Column(name = "policydescription", length= 200)
	private String policyDescription;
	@Column(name = "tenure", length= 10)
	private int tenure;
	@Column(name = "monthlypremium", length= 10)
	private int monthlyPremium;
	@Column(name = "maturityamount", length=10)
	private float maturityAmount;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "policytypeid", referencedColumnName = "id")
	private PolicyTypes policyTypes;


	
	
	

	
	


	

}
