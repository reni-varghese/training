package com.cts.policymanagementsystem.policyplans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cts.policymanagementsystem.policyplans.entities.Policies;
import com.cts.policymanagementsystem.policyplans.repos.PoliciesRepository;

@SpringBootApplication
public class PolicyplanApplication{
	
;

	public static void main(String[] args) {
		SpringApplication.run(PolicyplanApplication.class, args);
	}


	
	
}


