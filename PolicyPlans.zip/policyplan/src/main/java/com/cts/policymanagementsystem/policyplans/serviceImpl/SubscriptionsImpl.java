package com.cts.policymanagementsystem.policyplans.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.policymanagementsystem.policyplans.entities.Subscriptions;
import com.cts.policymanagementsystem.policyplans.repos.SubscriptionsRepository;
import com.cts.policymanagementsystem.policyplans.service.SubscriptionsService;

@Service
public class SubscriptionsImpl implements SubscriptionsService {
	
	@Autowired
	private SubscriptionsRepository repository;

	@Override
	public Subscriptions addSubscriptions( Subscriptions subscriptions) {

		return repository.save(subscriptions);
		
	}

	
	
	

}
