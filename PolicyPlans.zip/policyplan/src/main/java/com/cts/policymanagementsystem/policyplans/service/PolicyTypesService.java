package com.cts.policymanagementsystem.policyplans.service;

import java.util.List;

import com.cts.policymanagementsystem.policyplans.entities.PolicyTypes;

public interface PolicyTypesService {
	
	
	//a. Get all policy types list
	List<PolicyTypes> getAllPolicyTypes();

}
