package com.cts.policymanagementsystem.policyplans.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.policymanagementsystem.policyplans.entities.Subscriptions;

public interface SubscriptionsRepository extends CrudRepository<Subscriptions, Integer> {
	
	Subscriptions save(Subscriptions subscriptions);

}
