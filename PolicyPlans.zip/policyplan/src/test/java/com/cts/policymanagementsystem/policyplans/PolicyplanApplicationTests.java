package com.cts.policymanagementsystem.policyplans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyplanApplicationTests {

	@Test
	void contextLoads() {
	}

}
