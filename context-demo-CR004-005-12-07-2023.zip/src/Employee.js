
import { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import EmployeeContext from './contexts/EmployeeContext';

const Employee = ({ employee }) => {

    const context=useContext(EmployeeContext)

    const navigate = useNavigate();

    const onUpdate = (id) => {
        navigate(`/update/${id}`)
    }

    const onDelete=(emp)=>{
        let response=window.confirm(`Do you wish to delete employee ${emp.name}?`)
        if(response){
            let employees=context.employees.filter(e=>e.id!=emp.id)
            context.employees=employees;
        }

        navigate("/employees")

    }

    return (
        <tr>
                <td>{employee.id}</td>
                <td>{employee.name}</td>
                <td>{employee.gender}</td>
                <td>{employee.age}</td>
                <td>{employee.salary}</td>
            <td>
                <button onClick={()=>onUpdate(employee.id)} className="btn btn-warning">Update</button>
                &nbsp;
                &nbsp;
                <button onClick={()=>onDelete(employee)} className="btn btn-danger">Delete</button>
                </td>

        </tr>
        )
}

export default Employee; 