import "bootstrap/dist/css/bootstrap.min.css"
import AddEmployee from "./AddEmployee";
import EmployeeContext from './contexts/EmployeeContext';
import EmployeeList from './EmployeeList';
import { createBrowserRouter,RouterProvider,Navigate } from 'react-router-dom';
import UpdateEmployee from "./UpdateEmployee";

const router = createBrowserRouter([

    { path: "/employees", element: <EmployeeList /> },
    { path: "/add", element: <AddEmployee /> },
    { path: "/", element: <Navigate to="/employees" /> },
    { path: "/update/:id", element: <UpdateEmployee/> }

    ])

function App() {
  return (
    <div className="container">
      <EmployeeContext.Provider value={{
        employees: [
          {id:1,name:"Mark",gender:"Male",age:23,salary:45000},
          {id:2,name:"Mary",gender:"Female",age:21,salary:55000},
          {id:3,name:"Sara",gender:"Female",age:26,salary:75000},
          {id:4,name:"Anil",gender:"Male",age:23,salary:45000},
        ]
      }}>
              <RouterProvider router={ router}/>
        
      </EmployeeContext.Provider>
      
    </div>
  );
}

export default App;
