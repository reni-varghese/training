package com.cts;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.controller.EmployeeController;
import com.cts.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
	private static Scanner sc=new Scanner(System.in);
	private static EmployeeController controller;
	
    public static void main( String[] args )
    {
    	
    	ApplicationContext context=
    			new ClassPathXmlApplicationContext("spring.xml");
    	
    	controller=(EmployeeController) context.getBean("employeeController");
    	
    	int choice=0;
    	
    	while(true) {
    		System.out.println("1. List All Employees");
    		System.out.println("2. Get Employee By Id");
    		System.out.println("3. Add Employee");
    		System.out.println("4. Update Employee");
    		System.out.println("5. Delete Employee");
    		System.out.println("6. Exit");
    		choice=sc.nextInt();
    		switch (choice) {
			case 1:
				listAll();
				break;
			case 2:
				getByid();
				break;
			case 3:
				addEmployee();
				break;
			case 4:
				updateEmployee();
				break;
			case 5:
				deleteEmployee();
				break;
			case 6:
				System.exit(0);

			default:
				break;
			}
    	}
       
    }
    
    private static void listAll() {
    	List<Employee> employees=controller.getEmployees();
    	for (Employee employee : employees) {
			System.out.println(employee);
		}
    	System.out.println();
    }
    
    private static void getByid() {
    	System.out.println("Enter the Id of the Employee");
    	int id=sc.nextInt();
    			
    	Employee employee=controller.getById(id);
    	System.out.println( employee);
    	System.out.println();
    }
    
    private static void addEmployee() {
    	Employee employee=new Employee();
    	System.out.println("Enter id");
    	employee.setId(sc.nextInt());
    	sc.nextLine();
    	System.out.println("Enter Name");
    	employee.setName(sc.nextLine());
    	System.out.println("Enter Gender");
    	employee.setGender(sc.nextLine());
    	System.out.println("Enter Age");
    	employee.setAge(sc.nextInt());
    	System.out.println("Enter Salary");
    	employee.setSalary(sc.nextDouble());
    	String result=controller.add(employee);
    	System.out.println(result);
    	System.out.println();
    }
    private static void updateEmployee() {
    	Employee employee=new Employee();
    	System.out.println("Enter id");
    	employee.setId(sc.nextInt());
    	sc.nextLine();
    	System.out.println("Enter Name");
    	employee.setName(sc.nextLine());
    	System.out.println("Enter Gender");
    	employee.setGender(sc.nextLine());
    	System.out.println("Enter Age");
    	employee.setAge(sc.nextInt());
    	System.out.println("Enter Salary");
    	employee.setSalary(sc.nextDouble());
    	String result=controller.update(employee);
    	System.out.println(result);
    	System.out.println();
    }
    private static void deleteEmployee() {
    	System.out.println("Enter the Id of the Employee");
    	int id=sc.nextInt();
    	String result=controller.delete(id);
    	System.out.println(result);
    	System.out.println();
    }
}
