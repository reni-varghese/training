package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.cts.model.Employee;
import com.cts.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;

	public List<Employee> getEmployees(){
		return employeeService.getAll();
				
	}
	
	public Employee getById(int id) {
		return employeeService.getById(id);
	}
	
	public String add(Employee employee) {
		return employeeService.addEmployee(employee);
	}
	
	public String update(Employee employee) {
		return employeeService.updateEmployee(employee);
	}
	public String delete(int id) {
		return employeeService.deleteEmployee(id);
	}
}
