package com.cts.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cts.model.Employee;
@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("select * from employee",
				new EmployeeMapper());
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		return jdbcTemplate.queryForObject("select * from employee where id=?", 
				new EmployeeMapper(),id);
	}

	@Override
	public String addEmployee(Employee employee) {
		jdbcTemplate.update("insert into employee values(?,?,?,?,?)",
				employee.getId(),employee.getName(),employee.getGender(),employee.getAge()
				,employee.getSalary());
		return "Employee with Id "+employee.getId()+" saved successfully";
	}

	@Override
	public String updateEmployee(Employee employee) {
		jdbcTemplate.update("update employee set name=?,gender=?,age=?,salary=? where id=?",
				employee.getName(),employee.getGender(),employee.getAge(),employee.getSalary()
				,employee.getId());
		return "Employee with Id "+employee.getId()+" udpated successfully";
	}

	@Override
	public String deleteEmployee(int id) {
		jdbcTemplate.update("delete from employee where id=?",id);
		
		return "Employee with Id "+id+" deleted successfully";
	}

}
