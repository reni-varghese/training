import { useState } from "react";

const Button=(props)=>{

   

   const onButtonClick=()=>{
    props.onClick();
   }

   return(
    <div>
        <br/>
        <br/>
        <button className="btn  btn-primary" onClick={onButtonClick}>+1</button>

    </div>

   )
}

export default Button;