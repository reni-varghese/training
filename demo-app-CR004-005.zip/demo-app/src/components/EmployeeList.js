const EmployeeList=(props)=>{
    return(
        <div>
            <h3 className="text-primary">Employee Details</h3>
            <table className="table table-striped table-bordered">
                <tbody>
                    <tr>
                        <th>Employee Id</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Salary</th>
                        <th>Actions</th>
                    </tr>
                </tbody>
                <tbody>
                    {props.employees.map(emp=><tr>
                        <td>{emp.id}</td>
                        <td>{emp.name}</td>
                        <td>{emp.gender}</td>
                        <td>{emp.age}</td>
                        <td>{emp.salary}</td>
                        <td>
                            <a className="btn btn-primary" href="#">Delete</a>
                        </td>
                    </tr>)}
                </tbody>
            </table>
        </div>
    )
}

export default EmployeeList;