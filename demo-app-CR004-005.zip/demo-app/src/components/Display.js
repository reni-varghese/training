const Display=(props)=>{

    return(
        <div>
            <h6>{props.count}</h6>
        </div>
          
    );
}

export default Display;
