import "bootstrap/dist/css/bootstrap.min.css"
import { useState } from "react";
import AddEmployee from "./components/AddEmployee";
import Button from "./components/Button";
import Display from "./components/Display";
import EmployeeList from "./components/EmployeeList";
import NewButton from "./components/NewButton";
function App() {
  
  const [employees,setEmployees]=useState([
    {id:1,name:"Shilpa",gender:"Female",age:23,salary:34000},
    {id:2,name:"Anil",gender:"Male",age:21,salary:23000},
    {id:3,name:"Binu",gender:"Male",age:34,salary:67000},
    {id:4,name:"Anu",gender:"Female",age:26,salary:78000},
  ])

  const onAddEmploye=(employee)=>{
    setEmployees(prevState=>[...prevState,employee]);
  }

  return (
    <div className='container'>
      <EmployeeList employees={employees}/>
      <br/>
      <br/>
      <hr/>
      <AddEmployee onAdd={onAddEmploye}/>
    </div>
  );
}

export default App;
