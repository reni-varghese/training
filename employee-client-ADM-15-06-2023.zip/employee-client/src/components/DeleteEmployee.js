import { useEffect, useState,useRef } from "react";
import { useParams,useNavigate } from "react-router-dom";
import { deleteEmployee, getById } from "../service/api";
const DeleteEmployee=()=>{
    const params=useParams();
    const [id,setId]=useState('');
    const [name,setName]=useState('')
    const [gender,setGender]=useState('')
    const [age,setAge]=useState('')
    const [salary,setSalary]=useState('')
    const navigate=useNavigate();
    const navigate1=useNavigate();

    const flag=useRef(true);
    
    useEffect(()=>{
        if(flag.current){
            flag.current=false;
            return async()=>{
                const response=await getById(params.id);
                
                setId(response.id);
                setName(response.name);
                setGender(response.gender);
                setAge(response.age);
                setSalary(response.salary);
                
      
            }
        }
        
    },[])

    const onDelete=async ()=>{
        console.log("Id "+id)
        const response=await deleteEmployee(id);
        navigate1("/");
    }
    const onCancel=()=>{
        navigate("/");
    }


    return (
        <div>
            <h3 className="text-danger">Do you wish to continue?</h3>
            <table className="table table-striped table-bordered">
                <tbody>
                    <tr>
                        <td>Employee id</td>
                        <td>{id}</td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>{name}</td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td>{gender}</td>
                    </tr>
                    <tr>
                        <td>Age</td>
                        <td>{age}</td>
                    </tr>
                    <tr>
                        <td>Salary</td>
                        <td>{salary}</td>
                    </tr>
                </tbody>
            </table>
            <br/>
            <button className="btn btn-danger" onClick={onDelete}>Delete</button>
            &nbsp;
            <button className="btn btn-success" onClick={onCancel}>Cancel</button>
        </div>

        
    )
}

export default DeleteEmployee;