import { useParams,useNavigate } from "react-router-dom";
import { useEffect,useState } from "react";
import { getById, updateEmployee } from "../service/api";
import './UpdateEmployee.css';
const UpdateEmployee=(props)=>{
    const params=useParams();
    const [id,setId]=useState('');
    const [name,setName]=useState('')
    const [gender,setGender]=useState('')
    const [age,setAge]=useState('')
    const [salary,setSalary]=useState('')
    const navigate=useNavigate();
    useEffect(()=>{
        return async ()=>{
            const response=await getById(params.id);
            setId(response.id);
            setName(response.name);
            setGender(response.gender);
            setAge(response.age);
            setSalary(response.salary);
        }
    },[])

    const idChangeHandler=(event)=>{
        setId(event.target.value);
    }
    const nameChangeHandler=(event)=>{
        setName(event.target.value);
    }
    const genderChangeHandler=(event)=>{
        setGender(event.target.value);
    }
    const ageChangeHandler=(event)=>{
        setAge(event.target.value)
    }
    const salaryChangeHandler=(event)=>{
        setSalary(event.target.value);
    }
    const onUpdate=async (event)=>{
        event.preventDefault();
        const employee={
            id,
            name,
            gender,
            age,
            salary
        }
        
        const response=await updateEmployee(employee);
        navigate("/");
    }

    
    return(
        <div className="col-4">
            <h4 className="text-primary">Update Employee</h4>
            <form onSubmit={onUpdate}>
                <div className="form-group">
                    <label>Employee Id</label>
                    <input type="text" className="form-control" value={id} onChange={idChangeHandler}/>
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" className="form-control" value={name} onChange={nameChangeHandler}/>
                </div>
                <div className="form-group">
                    <label>Gender</label>
                    <div className="form-check-inline">
                        <input className="form-check-input" type="radio" value="Male" name='gender'
                        checked={gender==="Male" ? 'checked' : ''} onChange={genderChangeHandler}
                        />
                        <label className="form-check-label">Male</label>
                    </div>
                    <div className="form-check-inline">
                        <input className="form-check-input" type="radio" value="Male" name='gender'
                        checked={gender==="Female" ? 'checked' : ''} onChange={genderChangeHandler}
                        />
                        <label className="form-check-label">Female</label>
                    </div>
                </div>
                <div className="form-group">
                    <label>Age</label>
                    <input type="text" className="form-control" value={age} onChange={ageChangeHandler}/>
                </div>
                <div className="form-group">
                    <label>Salary</label>
                    <input type="text" className="form-control" value={salary} onChange={salaryChangeHandler}/>
                </div>
                <br/>
                <button className="btn btn-primary">Update</button>
            </form>
        </div>
    )
}

export default UpdateEmployee;