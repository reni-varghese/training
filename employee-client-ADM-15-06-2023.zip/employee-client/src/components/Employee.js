import { Link } from "react-router-dom";
const Employee=({employee})=>{

    return (
        <tr>
            <td>{employee.id}</td>
            <td>{employee.name}</td>
            <td>{employee.gender}</td>
            <td>{employee.age}</td>
            <td>{employee.salary}</td>
            <td>
                <Link to={`/update/${employee.id}`} className="btn btn-warning">Update</Link>&nbsp; | &nbsp; 
                <Link to={`/delete/${employee.id}`} className="btn btn-danger">Delete</Link>
            </td>
        </tr>
    )
}
export default Employee;