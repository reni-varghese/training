package com.cts.model;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Employee {

	private int id;
	@NotEmpty
	@Pattern(regexp = "[A-Z][A-Za-z\s]+",message = "Name should contain only alphabets")
	private String name;
	private String gender;
	@Min(value=18,message = "Age for the employee should be above 18")
	@Max(60)
	private int age;
	private double salary;
}
