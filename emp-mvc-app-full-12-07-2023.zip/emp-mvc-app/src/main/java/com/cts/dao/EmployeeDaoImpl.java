package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cts.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Employee> getAll(){
		
		return jdbcTemplate.query("select *from employee", new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				Employee employee=new Employee();
				employee.setId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setGender(rs.getString(3));
				employee.setAge(rs.getInt(4));
				employee.setSalary(rs.getDouble(5));
				
				return employee;
			}
			
		});
		
	}
	
	@Override
	public Employee getById(int id) {
		return jdbcTemplate.queryForObject("select * from employee where id=?",
				(rs,rowNum)->new Employee(rs.getInt("id"),rs.getString("name"),
						rs.getString("gender"),rs.getInt("age"),rs.getDouble("salary")),id);
	}
	
	
	@Override
	public void addEmployee(Employee employee) {
		jdbcTemplate.update("insert into employee values(?,?,?,?,?)",
				employee.getId(),employee.getName(),employee.getGender(),
				employee.getAge(),employee.getSalary());
	}
	
	@Override
	public void updateEmployee(Employee employee) {
		jdbcTemplate.update("update employee set name=?,gender=?,age=?,salary=? where id=?",
				employee.getName(),employee.getGender(),employee.getAge(),employee.getSalary(),
				employee.getId());
	}
	
	@Override
	public void deleteEmployee(int id) {
		jdbcTemplate.update("delete from employee where id=?",id);
	}
	
}
