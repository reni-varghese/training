
import { useNavigate } from 'react-router-dom';

const Employee = ({ employee }) => {

    const navigate = useNavigate();

    const onUpdate = (id) => {
        navigate(`/update/${id}`)
    }

    return (
        <tr>
                <td>{employee.id}</td>
                <td>{employee.name}</td>
                <td>{employee.gender}</td>
                <td>{employee.age}</td>
                <td>{employee.salary}</td>
            <td>
                <button onClick={()=>onUpdate(employee.id)} className="btn btn-warning">Update</button>
                &nbsp;
                &nbsp;
                <button className="btn btn-danger">Delete</button>
                </td>

        </tr>
        )
}

export default Employee; 