import { useContext } from "react"
import EmployeeContext from "./contexts/EmployeeContext"
import Employee from "./Employee";
import { useNavigate } from 'react-router-dom';

const EmployeeList=()=>{

    const context = useContext(EmployeeContext);

    const navigate = useNavigate();

    const onAddNew = () => {
        navigate("/add")
    }
    
    return(
        <div>
            <h3 className="text-primary">Employee Details</h3>
            <button onClick={ onAddNew} className="btn btn-primary">Add New</button>
            <table className="table  table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Employee Id</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Salary</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {context.employees.map(emp => <Employee key={ emp.id} employee={emp}/>)}
                </tbody>
            </table>
        </div>
    )
}

export default EmployeeList