import React from 'react';

const EmployeeContext=React.createContext({});



export default EmployeeContext;