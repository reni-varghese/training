package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpMvcAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpMvcAppApplication.class, args);
	}

}
