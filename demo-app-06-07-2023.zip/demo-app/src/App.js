import "bootstrap/dist/css/bootstrap.min.css"
import { useState } from "react";
import AddEmployee from "./components/AddEmployee";
import Button from "./components/Button";
import Display from "./components/Display";
import EmployeeList from "./components/EmployeeList";
import NewButton from "./components/NewButton";
import UpdateEmployee from "./components/UpdateEmployee";
function App() {
  
  const [employees,setEmployees]=useState([
    {id:1,name:"Shilpa",gender:"Female",age:23,salary:34000},
    {id:2,name:"Anil",gender:"Male",age:21,salary:23000},
    {id:3,name:"Binu",gender:"Male",age:34,salary:67000},
    {id:4,name:"Anu",gender:"Female",age:26,salary:78000},
  ])
    const [isAdd,setIsAdd]=useState(false);
    const [isUpdate,setIsUpdate]=useState(false);
    const [filteredEmployee,setFilteredEmployee]=useState({})

  const onAddEmploye=(employee)=>{
    setEmployees(prevState=>[...prevState,employee]);
    setIsAdd(false);
  }

  const onDelete=(id)=>{
    setEmployees(prev=>prev.filter(emp=>emp.id!=id));
  }
  const onClickAddNew=()=>{
    console.log("Hello")
    setIsAdd(true)
  }
  const onClickUpdate=(id)=>{
    setIsUpdate(true)
    
    const emp=employees.filter(e=>e.id===id);
    
    setFilteredEmployee(emp);
  }

  return (
    <div className='container'>
      <EmployeeList employees={employees} onDelete={onDelete} 
      onClickAddNew={onClickAddNew} onUpdate={onClickUpdate}/>
      <br/>
      <br/>
      <hr/>
      {isAdd && <AddEmployee onAdd={onAddEmploye}/>}
      {isUpdate && <UpdateEmployee employee={filteredEmployee} />}
    </div>
  );
}

export default App;
