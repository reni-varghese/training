import { useEffect, useState } from "react";
const UpdateEmployee=(props)=>
{
    const [id,setId]=useState('');
    const [name,setName]=useState('')
    const [gender,setGender]=useState('')
    const [age,setAge]=useState('')
    const [salary,setSalary]=useState('')
    const [employee,setEmployee]=useState({});
   
    useEffect(()=>{
        return ()=>{
            setEmployee(props.employee)
            
        }
    },[])
    
    const onIdChange=(event)=>{
        setId(event.target.value);
    }
    const onNameChange=(event)=>{
        setName(event.target.value);
    }
    const onGenderChange=(event)=>{
        setGender(event.target.value);
    }
    const onAgeChange=(event)=>{
        setAge(event.target.value);
    }
    const onSalaryChange=(event)=>{
        setSalary(event.target.value);
    }

    const onUpdateEmployee=(event)=>{
        event.preventDefault();
        const employee={
            id,
            name,
            gender,
            age,
            salary
        }
        props.onAdd(employee);

    }




    return(
        <div>
            <h3 className="text-primary">Update Employee</h3>
            <form className="col-5" onSubmit={onUpdateEmployee}>
                <div className="form-group">
                    <label>Employee Id</label>
                    <input type="text" className="form-control" onChange={onIdChange} value={employee.id}/>
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" className="form-control" onChange={onNameChange} 
                    value={employee.name} />
                </div>
                <div className="form-group">
                    <label>Gender</label>
                    &nbsp;
                    <div className="form-check-inline">
                        <input type="radio" className="form-check-input" name="gender" value="Male"
                        onChange={onGenderChange}/>
                        <label className="form-check-label">Male</label>
                    </div>
                    &nbsp;
                    <div className="form-check-inline">
                        <input type="radio" className="form-check-input" name="gender" value="Female"
                        onChange={onGenderChange}/>
                        <label className="form-check-label">Female</label>
                    </div>
                </div>
                <div className="form-group">
                    <label>Age</label>
                    <input type="text" className="form-control" onChange={onAgeChange} 
                    value={props.employee.age}/>
                </div>
                <div className="form-group">
                    <label>Salary</label>
                    <input type="text" className="form-control" onChange={onSalaryChange}
                    value={props.employee.salary} />
                </div>
                <br/>
                <button className="btn btn-info">Update Employee</button>
            </form>
        </div>
    )

}

export default UpdateEmployee;