const EmployeeList=(props)=>{

    
    return(
        <div>
            <h3 className="text-primary">Employee Details</h3>
            <button onClick={()=>props.onClickAddNew()} className="btn btn-primary">Add New</button>
            <table className="table table-striped table-bordered">
                <tbody>
                    <tr>
                        <th>Employee Id</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Salary</th>
                        <th>Actions</th>
                    </tr>
                </tbody>
                <tbody>
                    {props.employees.map(emp=><tr key={emp.id}>
                        <td>{emp.id}</td>
                        <td>{emp.name}</td>
                        <td>{emp.gender}</td>
                        <td>{emp.age}</td>
                        <td>{emp.salary}</td>
                        <td>
                            <button onClick={()=>props.onDelete(emp.id)} className="btn btn-primary">Delete</button>
                            &nbsp;&nbsp;
                            <button className="btn btn-success" onClick={()=>props.onUpdate(emp.id)}>Update</button>
                        </td>
                    </tr>)}
                </tbody>
            </table>
        </div>
    )
}

export default EmployeeList;