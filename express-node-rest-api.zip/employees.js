const employees=[
    {id:1,name:"Manu",gender:"Male",age:23,salary:45000},
    {id:2,name:"Asha",gender:"Female",age:21,salary:56000},
    {id:3,name:"Shivani",gender:"Female",age:25,salary:67000},
    {id:4,name:"Arun",gender:"Male",age:33,salary:56000},
]


module.exports=employees;