const express=require('express');
const employees=require('./employees');


const router=express.Router();

router.get("/api/employees",(req,res)=>{
    res.send(employees)
})

router.get("/api/employees/:id",(req,res)=>{
    console.log(req.params)
    
    const employee=employees.find(e=>e.id===+req.params.id)
    if(!employee){
        res.status(404).send({message:"Employee with Id "+req.params.id+" not found"})
    }
    res.send(employee)

})

router.post("/api/employees",(req,res)=>{

    const employee=req.body;
    employees.push(employee);
    res.status(201).send({message:"Employee with Id "+employee.id+" added successfully"})

})

router.put("/api/employees/:id",(req,res)=>{

    const employee=req.body;
    const emp=employees.find(e=>e.id===+req.params.id);
    if(!emp){
        return res.status(404).send({message:"Employee with Id "+req.params.id+" not found"})

    }
    
    if(employee.name){
        emp.name=employee.name
    }
    if(employee.gender){
        emp.gender=employee.gender;
    }
    if(employee.age){
        emp.age=employee.age;
    }
    if(employee.salary){
        emp.salary=employee.salary;
    }

    res.send({message:`Employee with id ${req.params.id} updated successfully`})

   })

   router.delete("/api/employees/:id",(req,res)=>{
    const employee=employees.find(e=>e.id===+req.params.id);
    if(!employee){
        return res.status(404).send({message:`Employee with id ${req.params.id} not found`})
    }
    const index=employees.indexOf(employee);
    employees.splice(index,1);
    res.send({message:`Employee with id ${req.params.id} deleted successfully`})
   })

   module.exports=router;
