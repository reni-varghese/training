import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

import EmployeeList from "./components/EmployeeList";
import AddEmployee from "./components/AddEmployee";
import UpdateEmployee from "./components/UpdateEmployee";
import DeleteEmployee from "./components/DeleteEmployee";

const router = createBrowserRouter([
  { path: "/", element: <EmployeeList /> },
  { path: "/add", element: <AddEmployee /> },
  { path: "/update/:id", element: <UpdateEmployee /> },
  { path: "/delete/:id", element: <DeleteEmployee /> },
]);

function App() {
  return (
    <div className="container">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
