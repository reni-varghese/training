import { useState } from "react";
import {saveEmployee} from '../service/api';
import { useNavigate } from "react-router-dom";
const AddEmployee=(props)=>{

    const [id,setId]=useState('');
    const [name,setName]=useState('');
    const [gender,setGender]=useState('');
    const [age,setAge]= useState('');
    const [salary,setSalary]=useState('');

    const navigate=useNavigate();


    const idChangeHandler=(event)=>{
        setId(event.target.value);
    }
    const nameChangeHandler=(event)=>{
        setName(event.target.value);
    }
    const genderChangeHandler=(event)=>{
        setGender(event.target.value);
    }
    const ageChangeHandler=(event)=>{
        setAge(event.target.value);
    }
    const salaryChangeHandler=(event)=>{
        setSalary(event.target.value);
    }

    const onSave= async (event)=>{
        event.preventDefault();
        const employee={
            id,
            name,
            gender,
            age,
            salary

        }
        console.log(employee);
        const result=await saveEmployee(employee);
        console.log(result);

        navigate("/");



    }



    return (
        <div className="col-4">
            <form onSubmit={onSave}>
                <div className="form-group">
                    <label>Employee id</label>
                    <input type="text" className="form-control" onChange={idChangeHandler}/>
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" className="form-control" onChange={nameChangeHandler}/>
                </div>
                <div className="form-group">
                    <label>Gender</label>
                    <div className="form-check-inline">
                        <input type="radio" className="form-check-input" value="Male" name="gender"
                        onChange={genderChangeHandler}/>
                        <label className="form-check-label">Male</label>
                    </div>
                    <div className="form-check-inline">
                        <input type="radio" className="form-check-input" value="Female" name="gender"
                        onChange={genderChangeHandler}/>
                        <label className="form-check-label">Female</label>
                    </div>
                </div>
                <div className="form-group">
                    <label>Age</label>
                    <input type="text" className="form-control" onChange={ageChangeHandler}/>
                </div>
                <div className="form-group">
                    <label>Salary</label>
                    <input type="text" className="form-control" onChange={salaryChangeHandler}/>
                </div>
                <button className="btn btn-primary">Save Employee</button>
            </form>
        </div>
    )
}
export default AddEmployee;