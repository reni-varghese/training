import { useParams, useNavigate, Link, redirect } from "react-router-dom";
import { useEffect, useState, useRef } from "react";
import { deleteEmployee, getById } from "../service/api";
const DeleteEmployee = () => {
  const params = useParams();
  const [id, setId] = useState();
  const [name, setName] = useState();
  const [gender, setGender] = useState();
  const [age, setAge] = useState();
  const [salary, setSalary] = useState();
  const [message, setMessage] = useState();

  const navigate = useNavigate();
  const flag = useRef(true);

  useEffect(() => {
    if (flag.current) {
      return async () => {
        flag.current = false;
        const employee = await getById(params.id);
        setId(employee.id);
        setName(employee.name);
        setGender(employee.gender);
        setAge(employee.age);
        setSalary(employee.salary);
      };
    }
  }, []);

  const onCancel = () => {
    console.log("Oncancel");
    navigate("/");
  };
  const onDelete = async (event) => {
    event.preventDefault();
    console.log("Inside Delete");

    console.log(id);
    const response = await deleteEmployee(id);
    console.log(response);
    navigate("/");
  };

  return (
    <div className="col-6">
      <h1 className="text-danger">Delete Employee</h1>
      <br />
      <table className="table table-striped table-bordered">
        <tbody>
          <tr>
            <td>Employee id</td>
            <td>{id}</td>
          </tr>
          <tr>
            <td>Name</td>
            <td>{name}</td>
          </tr>
          <tr>
            <td>Gender</td>
            <td>{gender}</td>
          </tr>
          <tr>
            <td>Age</td>
            <td>{age}</td>
          </tr>
          <tr>
            <td>Salary</td>
            <td>{salary}</td>
          </tr>
        </tbody>
      </table>
      <button className="btn btn-danger" onClick={onDelete}>
        Delete
      </button>
      &nbsp;
      <button className="btn btn-success" onClick={onCancel}>
        Cancel
      </button>
      <br />
      <br />
      {message}
      <Link to="/">Back to Main Page</Link>
    </div>
  );
};

export default DeleteEmployee;
