package reni.springframework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import reni.springframework.domain.Employee;
import reni.springframework.service.EmployeeService;

import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SpringBootTest
class EmployeeServiceApplicationTests {

    
    @Test
    public void testContext(){

      
    }

}
