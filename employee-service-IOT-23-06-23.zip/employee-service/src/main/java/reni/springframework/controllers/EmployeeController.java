package reni.springframework.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reni.springframework.domain.ResponseDto;
import reni.springframework.domain.Employee;
import reni.springframework.service.EmployeeService;

import java.util.Date;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/employees")
public class EmployeeController {

    private EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
    	
    	Date date=new Date(2022,5,21);
        this.employeeService = employeeService;
    }

    @GetMapping
    public List<Employee> getAllEmployees(){
        return employeeService.getAll();
    }


    @PostMapping
    public ResponseEntity<ResponseDto> add(@RequestBody Employee employee){
        String result=employeeService.addEmployee(employee);
        ResponseDto response=new ResponseDto();
        response.setMessage(result);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ResponseDto> updateEmployee(@PathVariable int id,@RequestBody Employee employee){
        String result=employeeService.updateEmployee(id,employee);
        ResponseDto responseDto=new ResponseDto();
        responseDto.setMessage(result);
        return new ResponseEntity<>(responseDto,HttpStatus.OK);
    }
    @GetMapping("/{id}")
    public Employee getById(@PathVariable int id){
        return employeeService.getById(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ResponseDto> deleteEmployee(@PathVariable int id){
        String result= employeeService.deleteEmployee(id);
        ResponseDto response=new ResponseDto();
        response.setMessage(result);
        System.out.println("Hello=====================================");
        return ResponseEntity.ok(response);
    }
}
