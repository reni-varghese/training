package reni.springframework.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;

import org.springframework.web.bind.annotation.ExceptionHandler;
import reni.springframework.exceptions.EmployeeNotFoundException;

@ControllerAdvice
public class ErrorHandler {

	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<CustomErrorResponse> handleEmployeeNotFound(EmployeeNotFoundException ex){
		CustomErrorResponse response=new CustomErrorResponse();
		response.setErrorMessage(ex.getMessage());
		response.setStatus(HttpStatus.NOT_FOUND);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
}
