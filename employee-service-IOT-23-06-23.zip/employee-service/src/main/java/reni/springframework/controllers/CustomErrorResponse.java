package reni.springframework.controllers;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CustomErrorResponse {

	private String errorMessage;
	private HttpStatus status;
}
