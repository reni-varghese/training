package reni.springframework.exceptions;

public class EmployeeNotFoundException extends RuntimeException {
    public EmployeeNotFoundException(String s) {
    }

    public EmployeeNotFoundException() {
        super();
    }
}
