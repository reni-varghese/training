package reni.springframework.service;

import org.springframework.stereotype.Service;
import reni.springframework.domain.Employee;
import reni.springframework.exceptions.EmployeeNotFoundException;
import reni.springframework.repositories.EmployeeRepository;

import java.util.List;
import java.util.Optional;
@Service
public class EmployeeServiceImpl implements  EmployeeService{

    private EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public List<Employee> getAll() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee getById(int id) {
        return employeeRepository.findById(id)
                .orElseThrow(()->new EmployeeNotFoundException("Employee with Id "+id+ " does not exist"));
    }

    @Override
    public String addEmployee(Employee employee) {
        employeeRepository.save(employee) ;
        return "Employee "+employee.getName()+" with Id "+employee.getId()+" saved successfully";
    }

    @Override
    public String updateEmployee(int id, Employee employee) {
        Optional<Employee> empOpt=employeeRepository.findById(id);
        if(!empOpt.isPresent()){
            throw new EmployeeNotFoundException("Employee with the id "+id+" does not exist");
        }
        Employee emp=empOpt.get();
        if(employee.getName()!=null){
            emp.setName(employee.getName());
        }
        if(employee.getGender()!=null){
            emp.setGender(employee.getGender());
        }
        if(employee.getAge()!=0){
            emp.setAge(employee.getAge());
        }
        if(employee.getSalary()!=0){
            emp.setSalary(employee.getSalary());
        }
        employeeRepository.save(emp);
        return "Employee with id "+id+" updated successfully";
    }

    @Override
    public String deleteEmployee(int id) {
        employeeRepository.deleteById(id);
        return "Employee with id "+id+" deleted successfully";
    }
}
