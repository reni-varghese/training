import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { UpdateEmployeeComponent } from './employee/update-employee.component';
import { DeleteEmployeeComponent } from './employee/delete-employee.component';
import { AddEmployeeGuard } from './employee/add-employee.guard';

const routes: Routes = [
  { path: 'employees', component: EmployeeListComponent },
  {
    path: 'add',
    component: AddEmployeeComponent,
    canDeactivate: [
      (component: AddEmployeeComponent) =>
        component.empForm.dirty
          ? confirm('Do you wish to discard the changes?')
          : true,
    ],
  },
  { path: 'update/:id', component: UpdateEmployeeComponent },
  { path: 'delete/:id', component: DeleteEmployeeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
