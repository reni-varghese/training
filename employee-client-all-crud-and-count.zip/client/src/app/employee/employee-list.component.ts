import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})
export class EmployeeListComponent implements OnInit {
  employees: Employee[];
  countRadioButtonValue: string = 'All';
  constructor(private employeeService: EmployeeService) {}
  ngOnInit(): void {
    this.employeeService.getEmployees().subscribe((data) => {
      this.employees = data;
    });
  }
  getTotalEmployeeCount() {
    return this.employees.length;
  }
  getMaleEmployeeCount() {
    return this.employees.filter((x) => x.gender === 'Male').length;
  }

  getFemaleEmployeeCount() {
    return this.employees.filter((x) => x.gender === 'Female').length;
  }
  onSelectedRadioButtonValueChange(value: string) {
    this.countRadioButtonValue = value;
    console.log('Employee list', this.countRadioButtonValue);
  }
}
