import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from './employee';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  constructor(private http: HttpClient) {}

  getEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>('http://localhost:8080/employees');
  }

  addEmployee(employee: Employee) {
    return this.http.post('http://localhost:8080/employees', employee);
  }

  getById(id: number): Observable<Employee> {
    return this.http.get<Employee>(`http://localhost:8080/employees/${id}`);
  }

  updateEmployee(employee: Employee) {
    return this.http.put(
      `http://localhost:8080/employees/${employee.id}`,
      employee
    );
  }

  deleteEmployee(id: number) {
    return this.http.delete(`http://localhost:8080/employees/${id}`);
  }
}
