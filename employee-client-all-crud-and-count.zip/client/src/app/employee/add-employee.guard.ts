import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanDeactivate,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AddEmployeeComponent } from './add-employee.component';

@Injectable({
  providedIn: 'root',
})
export class AddEmployeeGuard implements CanDeactivate<AddEmployeeComponent> {
  canDeactivate(
    component: AddEmployeeComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (component.empForm.dirty) {
      return confirm('Do you want to discard the changes?');
    }
    return true;
  }
}
