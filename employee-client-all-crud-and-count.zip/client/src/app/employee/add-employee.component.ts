import { Component, ViewChild } from '@angular/core';
import { EmployeeService } from './employee.service';
import { Employee } from './employee';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css'],
})
export class AddEmployeeComponent {
  @ViewChild('empForm')
  empForm: NgForm;
  constructor(
    private employeeService: EmployeeService,
    private router: Router
  ) {}

  onAdd(employee: Employee) {
    this.employeeService.addEmployee(employee).subscribe((data) => {
      console.log(data);
      this.router.navigate(['/employees']);
    });
  }
}
