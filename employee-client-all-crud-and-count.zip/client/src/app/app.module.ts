import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { UpdateEmployeeComponent } from './employee/update-employee.component';
import { DeleteEmployeeComponent } from './employee/delete-employee.component';
import { EmployeeCountComponent } from './employee/employee-count.component';

@NgModule({
  declarations: [AppComponent, EmployeeListComponent, AddEmployeeComponent, UpdateEmployeeComponent, DeleteEmployeeComponent, EmployeeCountComponent],
  imports: [BrowserModule, AppRoutingModule, HttpClientModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
