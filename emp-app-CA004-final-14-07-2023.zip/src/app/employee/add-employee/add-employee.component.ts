import { EmployeeService } from './../employee.service';
import { Employee } from './../employee';
import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgFor } from '@angular/common';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent {


  @ViewChild("empForm")
  employeeForm:NgForm

  constructor(private employeeService:EmployeeService,
    private router:Router){}

  onAdd(employee:Employee){
    this.employeeService.addEmployee(employee);
    this.router.navigate(["/employees"])
  }

}
