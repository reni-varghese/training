import { TestBed } from '@angular/core/testing';
import { CanDeactivateFn } from '@angular/router';

import { addEmployeeGuard } from './add-employee.guard';

describe('addEmployeeGuard', () => {
  const executeGuard: CanDeactivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => addEmployeeGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
