import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { CanDeactivateFn } from '@angular/router';

export const addEmployeeGuard: CanDeactivateFn<AddEmployeeComponent> = (component:AddEmployeeComponent) => {
  
  if(component.employeeForm.dirty){
    return confirm("Do you wish to discard the changes??")
  }
  
  return true;
};
