import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllEmployees } from "./api";
const EmployeeList = (props) => {
  const [employees, setEmployees] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    return async () => {
      const empList = await getAllEmployees();
      console.log(empList);
      setEmployees(empList);
    };
  }, []);

  const onAddNew = () => {
    navigate("/add");
  };

  return (
    <div>
      <h1 className="text-primary">Employee List</h1>
      <button className="btn btn-primary" onClick={onAddNew}>
        Add New
      </button>
      <table className="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Employee Id</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Salary</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id}>
              <td>{emp.id}</td>
              <td>{emp.name}</td>
              <td>{emp.gender}</td>
              <td>{emp.age}</td>
              <td>{emp.salary}</td>
              <td>
                <a className="btn btn-warning" href="#">
                  Update
                </a>{" "}
                |{" "}
                <a className="btn btn-danger" href="#">
                  Delete
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeList;
