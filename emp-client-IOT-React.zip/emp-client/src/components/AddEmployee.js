import "./AddEmployee.css";
import { useState } from "react";
import { addEmployee } from "./api";
import { useNavigate } from "react-router-dom";
const AddEmployee = (props) => {
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [gender, setGender] = useState("");
  const [age, setAge] = useState("");
  const [salary, setSalary] = useState("");

  const navigate = useNavigate();

  const onIdChange = (event) => {
    setId(event.target.value);
  };
  const onNameChange = (event) => {
    setName(event.target.value);
  };
  const onGenderChange = (event) => {
    setGender(event.target.value);
  };
  const onAgeChange = (event) => {
    setAge(event.target.value);
  };
  const onSalaryChange = (event) => {
    setSalary(event.target.value);
  };

  const onAddEmployee = async (event) => {
    event.preventDefault();
    const employee = {
      id,
      name,
      gender,
      age,
      salary,
    };
    const response = await addEmployee(employee);
    console.log(response);
    navigate("/employees");
  };

  return (
    <div className="text-primary">
      <h1>Add Employee</h1>
      <form className="col-4" onSubmit={onAddEmployee}>
        <div className="form-group">
          <label>Employee id</label>
          <input
            type="text"
            name="id"
            className="form-control"
            onChange={onIdChange}
          />
        </div>
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            name="name"
            className="form-control"
            onChange={onNameChange}
          />
        </div>
        <div className="form-group">
          <label>Gender</label> &nbsp;
          <div className="form-check-inline">
            <input
              type="radio"
              name="gender"
              value="Male"
              className="form-check-input"
              onChange={onGenderChange}
            />
            <label className="form-check-label">Male</label>
          </div>
          &nbsp;
          <div className="form-check-inline">
            <input
              type="radio"
              name="gender"
              value="Female"
              className="form-check-input"
              onChange={onGenderChange}
            />
            <label className="form-check-label">Female</label>
          </div>
        </div>
        <div className="form-group">
          <label>Age</label>
          <input
            type="text"
            name="age"
            className="form-control"
            onChange={onAgeChange}
          />
        </div>
        <div className="form-group">
          <label>Salary</label>
          <input
            type="text"
            name="salary"
            className="form-control"
            onChange={onSalaryChange}
          />
        </div>
        <br />
        <button className="btn btn-primary">Add Employee</button>
      </form>
    </div>
  );
};

export default AddEmployee;
