import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import EmployeeList from "./components/EmployeeList";
import AddEmployee from "./components/AddEmployee";

const router = createBrowserRouter([
  { path: "/employees", element: <EmployeeList /> },
  { path: "/add", element: <AddEmployee /> },
]);

function App() {
  return (
    <div className="container">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
