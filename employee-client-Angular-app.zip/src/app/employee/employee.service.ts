import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }

  getAll(): Observable<Employee[]>{
    return this.http.get<Employee[]>("http://localhost:5000/api/employees")
  }

  addEmployee(employee:Employee){
    return this.http.post("http://localhost:5000/api/employees",employee);
  }

}
