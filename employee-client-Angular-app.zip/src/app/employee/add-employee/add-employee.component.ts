import { EmployeeService } from './../employee.service';
import { Employee } from './../employee';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent {

  constructor(private employeeService:EmployeeService,private router:Router){}


onSubmit(employee: Employee){
  this.employeeService.addEmployee(employee).subscribe(result=>{
    this.router.navigate(["/employees"]);
  })
}

}
