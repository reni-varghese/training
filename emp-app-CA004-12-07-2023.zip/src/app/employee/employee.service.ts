import { Injectable } from '@angular/core';
import { Employee } from './employee';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employees:Employee[]=[
    {id:1,name:"Mark",gender:"Male",age:23,salary:34000},
    {id:2,name:"Mary",gender:"Female",age:21,salary:89000},
    {id:3,name:"Anu",gender:"Female",age:25,salary:67000},
    {id:4,name:"Ajay",gender:"Male",age:34,salary:56000},
  ]

  constructor() { }

  addEmployee(employee:Employee){
    this.employees.push(employee)
  }

  getEmployeeId(id:any){
    return this.employees.find(e=>e.id==id);
  }

  updateEmployee(employee:Employee){
    let newEmployees=this.employees.filter(e=>e.id!=employee.id);
    newEmployees=[...newEmployees,employee];
    newEmployees.sort((a,b)=>a.id-b.id)
    this.employees=newEmployees;
    console.log("updated completed")
    

  }

  deleteEmployee(id:number){
    this.employees=this.employees.filter(emp=>emp.id!=id);
    console.log(this.employees)
  }



}
