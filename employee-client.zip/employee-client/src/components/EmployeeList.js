import { useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom";
import { getAllEmployees } from "../service/api";
import Employee from "./Employee";

const EmployeeList=()=>{

    const [employees,setEmployees]=useState([]);

    const navigate=useNavigate();

    useEffect(()=>{
        return async ()=>{
            const result=await getAllEmployees();
            console.log(result);
            setEmployees(result);
        }
    },[])
 
    const onAdd=()=>{
        navigate("/add");
    }



    return (
        <div>
            <button className="btn btn-primary" onClick={onAdd}>Add New</button>
            <table className="table table-striped table-borderd">
                <thead>
                    <tr>
                        <th>Employee Id</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Salary</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map(emp=><Employee key={emp.id} employee={emp}/>)}
                </tbody>
            </table>
        </div>
    )


}

export default EmployeeList