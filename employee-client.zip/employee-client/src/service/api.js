import axios from "axios";
const getAllEmployees=async ()=>{

    const response=await axios.get("http://localhost:8080/employees");
    return response.data;
}

const saveEmployee=async (employee)=>{
    const response=await axios.post("http://localhost:8080/employees",employee);
    return response.data;
}

export {getAllEmployees,saveEmployee};