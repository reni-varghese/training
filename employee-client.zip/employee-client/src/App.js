import {createBrowserRouter,RouterProvider} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'

import EmployeeList from './components/EmployeeList';
import AddEmployee from './components/AddEmployee';
import UpdateEmployee from './components/UpdateEmployee';


const router=createBrowserRouter([
  {path: "/", element: <EmployeeList/>},
  {path: "/add", element: <AddEmployee/>},
  {path: "/update", element: <UpdateEmployee/>}
])

function App() {
  return (
    <div className='container'>
      <RouterProvider router={router}/>
    </div>
  );
}

export default App;
