import React from "react";

class NewButton extends React.Component{

    state={count:0}

    // constructor(props){
    //   super(props);
    //   this.state={count:0}

    // }

    onButtonClick=()=>{
        this.props.onClick();
    }

    render(){
        return(
            <div>
                <button className="btn btn-danger" onClick={this.onButtonClick}>+1</button>
            </div>
        )
    }
}

export default NewButton;