const EmployeeList = (props) => {
  return (
    <div>
      <h3 className="text-primary">Employee Details</h3>
      <button onClick={props.onAdd} className="btn btn-primary">
        Add New
      </button>
      <table className="table table-striped table-bordered">
        <tbody>
          <tr>
            <th>Employee Id</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Salary</th>
            <th>Actions</th>
          </tr>
        </tbody>
        <tbody>
          {props.employees.map((emp) => (
            <tr>
              <td>{emp.id}</td>
              <td>{emp.name}</td>
              <td>{emp.gender}</td>
              <td>{emp.age}</td>
              <td>{emp.salary}</td>
              <td>
                <button
                  className="btn btn-primary"
                  onClick={() => props.onDelete(emp.id)}
                >
                  Delete
                </button>
                &nbsp;&nbsp;
                <button
                  onClick={() => props.onUpdate(emp.id)}
                  className="btn btn-success"
                >
                  Update
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeList;
