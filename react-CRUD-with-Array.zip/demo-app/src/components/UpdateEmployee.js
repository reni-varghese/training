import { useState, useEffect } from "react";
const UpdateEmployee = (props) => {
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [gender, setGender] = useState("");
  const [age, setAge] = useState("");
  const [salary, setSalary] = useState("");

  useEffect(() => {
    return () => {
      setId(props.employee.id);
      setName(props.employee.name);
      setGender(props.employee.gender);
      setAge(props.employee.age);
      setSalary(props.employee.salary);
    };
  }, []);

  const onIdChange = (event) => {
    setId(event.target.value);
  };
  const onNameChange = (event) => {
    setName(event.target.value);
  };
  const onGenderChange = (event) => {
    setGender(event.target.value);
  };
  const onAgeChange = (event) => {
    setAge(event.target.value);
  };
  const onSalaryChange = (event) => {
    setSalary(event.target.value);
  };

  const onAddEmployee = (event) => {
    event.preventDefault();
    const employee = {
      id,
      name,
      gender,
      age,
      salary,
    };
    props.onSaveEmployee(employee);
  };

  return (
    <div>
      <h3 className="text-primary">Add Employee</h3>
      <form className="col-5" onSubmit={onAddEmployee}>
        <div className="form-group">
          <label>Employee Id</label>
          <input
            type="text"
            className="form-control"
            value={id}
            onChange={onIdChange}
          />
        </div>
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            className="form-control"
            onChange={onNameChange}
            value={name}
          />
        </div>
        <div className="form-group">
          <label>Gender</label>
          &nbsp;
          <div className="form-check-inline">
            <input
              type="radio"
              className="form-check-input"
              name="gender"
              value="Male"
              onChange={onGenderChange}
              checked={props.employee.gender === "Male"}
            />
            <label className="form-check-label">Male</label>
          </div>
          &nbsp;
          <div className="form-check-inline">
            <input
              type="radio"
              className="form-check-input"
              name="gender"
              value="Female"
              onChange={onGenderChange}
              checked={props.employee.gender === "Female"}
            />
            <label className="form-check-label">Female</label>
          </div>
        </div>
        <div className="form-group">
          <label>Age</label>
          <input
            type="text"
            className="form-control"
            onChange={onAgeChange}
            value={age}
          />
        </div>
        <div className="form-group">
          <label>Salary</label>
          <input
            type="text"
            className="form-control"
            onChange={onSalaryChange}
            value={salary}
          />
        </div>
        <br />
        <button className="btn btn-primary">Add Employee</button>
      </form>
    </div>
  );
};

export default UpdateEmployee;
