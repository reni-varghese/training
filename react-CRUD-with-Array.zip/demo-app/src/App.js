import "bootstrap/dist/css/bootstrap.min.css";
import { useState } from "react";
import AddEmployee from "./components/AddEmployee";

import EmployeeList from "./components/EmployeeList";
import UpdateEmployee from "./components/UpdateEmployee";

function App() {
  const [employees, setEmployees] = useState([
    { id: 1, name: "Shilpa", gender: "Female", age: 23, salary: 34000 },
    { id: 2, name: "Anil", gender: "Male", age: 21, salary: 23000 },
    { id: 3, name: "Binu", gender: "Male", age: 34, salary: 67000 },
    { id: 4, name: "Anu", gender: "Female", age: 26, salary: 78000 },
  ]);

  const [isAdd, setIsAdd] = useState(false);
  const [isUpdate, setIsUpdate] = useState(false);
  const [filteredEmployee, setFilteredEmployee] = useState(null);

  const onAddNew = () => {
    setIsAdd((prev) => !prev);
  };

  const onUpdate = (id) => {
    const employee = employees.find((x) => x.id === id);
    setFilteredEmployee(employee);
    setIsUpdate(true);
  };

  const onSaveEmployee = (employee) => {
    let newEmployees = employees.filter((x) => x.id !== employee.id);
    newEmployees = [...newEmployees, employee];
    newEmployees.sort((a, b) => a.id - b.id);
    setEmployees(newEmployees);

    setIsUpdate(false);
  };

  const onAddEmploye = (employee) => {
    setEmployees((prevState) => [...prevState, employee]);
  };

  const onDelete = (id) => {
    setEmployees((prev) => prev.filter((x) => x.id !== id));
  };

  return (
    <div className="container">
      <EmployeeList
        employees={employees}
        onDelete={onDelete}
        onAdd={onAddNew}
        onUpdate={onUpdate}
      />
      <br />
      <br />
      <hr />
      {isAdd && <AddEmployee onAdd={onAddEmploye} onAddNew={onAddNew} />}
      {isUpdate && (
        <UpdateEmployee
          employee={filteredEmployee}
          onSaveEmployee={onSaveEmployee}
        />
      )}
    </div>
  );
}

export default App;
